# Edit this configuration, then create a new result directory with run.R.
config <- ExpressionStudyConfig()
