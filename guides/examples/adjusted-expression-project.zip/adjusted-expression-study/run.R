# Run from the unpacked project root: Rscript run.R rerun-results
source(file.path("R", "analysis.R"))
source("config.R")
args <- commandArgs(trailingOnly = TRUE)
if (length(args) > 1) stop("Supply at most one new output directory")
output_dir <- if (length(args)) args[1] else "results"
WriteExpressionStudy(output_dir, config)
code_files <- c(file.path("R", "analysis.R"), "config.R", "run.R", "report.qmd", "_quarto.yml")
write.csv(data.frame(file = code_files, md5 = unname(tools::md5sum(code_files))),
          file.path(output_dir, "code-manifest.csv"), row.names = FALSE)
cat("Results written to", output_dir, "\n")
