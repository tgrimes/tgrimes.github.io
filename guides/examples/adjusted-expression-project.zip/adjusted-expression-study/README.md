# A standardized expression contrast: reproducible teaching project

All people, feature IDs, assays, and results are synthetic. This is an associational example on a supplied calibrated log2 intensity scale. It demonstrates a target-based analysis, not a clinical finding or a validated RNA-seq pipeline.

## Rebuild from a fresh session

Analysis uses base R. Rendering additionally needs Quarto with a working R/knitr installation. The supplied `results/` and `report-output/report.html` are the reference run.

From this unpacked project directory:

```sh
Rscript run.R rerun-results
quarto render report.qmd -P results_dir:rerun-results
```

The first command refuses to overwrite a populated result directory. Use a new directory name for each experiment; pass that name as `results_dir` when rendering. The second command regenerates `report-output/report.html`. No network access, package installation, or external data acquisition occurs during the analysis. The reference report embeds its assets.

`config.R` creates an explicit editable list with sample size, feature count, seeds, folds, bounds, alpha, and simulation settings. The default experiment uses 800 people and 24 features, followed by 100 replicates at each of two sample sizes and four nuisance-model scenarios. Set the feature count to at least 8; all features belong to the tested family. In larger families, the fixed-dimension inference argument needs rechecking.

## Files and roles

- `R/analysis.R`: canonical base-R generator, alignment checks, cross-fitted estimator, evaluation, and output writer.
- `config.R`: explicit analysis settings.
- `run.R`: the documented execution entry point.
- `report.qmd`: report source; it reads a specified results directory and has freezing disabled.
- `results/observed_assay.csv`, `metadata.csv`, `features.csv`: observed study inputs, with missing outcomes represented by NA. Metadata are deliberately shuffled; match identifiers.
- `results/simulation_truth.csv`: oracle population contrasts used for evaluation, never supplied to the estimator. Missing complete outcomes are not retained.
- `results/results.csv`: every feature estimate, pointwise interval, BY-adjusted p-value, and discovery status.
- `results/diagnostics.csv`, `predictions.csv`, `influence_contributions.csv`, `fit-warnings.txt`: diagnostic and per-person audit records.
- `results/simulation_records.csv`: every attempted replicate/scenario with seeds, errors, and success status. Failed fits retain NA performance values.
- `results/simulation_summary.csv`: success counts, bias, coverage, FDR, and MCSE summaries conditional on success.
- `results/config.rds`, `config.txt`, `session-info.txt`: settings and software environment.
- `results/manifest.csv`, `code-manifest.csv`: local MD5 identity/change checks; no security guarantee is claimed. Manifests do not hash themselves. Code manifests are separate from the output manifest.

Session information and numerical details can differ across environments. Record the actual environment used; the archive is not a universal environment lockfile. Compare statistical outputs with the reference, and investigate differences rather than assuming bitwise identity on every platform.

## Interpretation boundaries

The target is the population average of group-specific conditional mean differences standardized over all eligible people's covariates. MAR and support identify it from observed outcomes. All nuisance models must be consistent and sufficiently fast for the displayed efficient-SE argument. Either outcome or joint-weight correctness can support double-robust consistency under controls, but that alone does not validate the same Wald intervals.

BY addresses arbitrary dependence among valid null p-values; it cannot repair invalid individual tests. In this example p-values are asymptotic approximations. Confidence intervals are pointwise, not simultaneous or adjusted for selection. The 24 within-dataset genes are not independent Monte Carlo replicates. The reference simulation is a teaching experiment, not a precision-powered benchmark.
